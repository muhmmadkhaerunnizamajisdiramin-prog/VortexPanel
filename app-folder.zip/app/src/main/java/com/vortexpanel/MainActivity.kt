package com.vortexpanel

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.vortexpanel.shizuku.ShizukuHelper
import com.vortexpanel.ui.screens.HomeScreen
import com.vortexpanel.ui.theme.VortexBlack
import com.vortexpanel.ui.theme.VortexPanelTheme
import com.vortexpanel.utils.BoostUtils

class MainActivity : ComponentActivity() {

    private var shizukuRunning by mutableStateOf(false)
    private var permissionGranted by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setupShizuku()

        setContent {
            VortexPanelTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = VortexBlack
                ) {
                    val context = LocalContext.current
                    HomeScreen(
                        context = context,
                        isShizukuRunning = shizukuRunning,
                        isPermissionGranted = permissionGranted,
                        onRequestPermission = { ShizukuHelper.requestPermission() },
                        onBoostClick = { performBoost() }
                    )
                }
            }
        }
    }

    private fun setupShizuku() {
        updateShizukuStatus()

        ShizukuHelper.addBinderReceivedListener { updateShizukuStatus() }
        ShizukuHelper.addBinderDeadListener {
            shizukuRunning = false
            permissionGranted = false
        }
        ShizukuHelper.addRequestPermissionResultListener { _, grantResult ->
            permissionGranted = grantResult == android.content.pm.PackageManager.PERMISSION_GRANTED
            if (permissionGranted) {
                Toast.makeText(this, "Permission granted!", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun updateShizukuStatus() {
        shizukuRunning = ShizukuHelper.isShizukuAvailable()
        permissionGranted = ShizukuHelper.isPermissionGranted()
    }

    private fun performBoost() {
        BoostUtils.clearMemory()
        val msg = if (permissionGranted) {
            "Boost activated with Shizuku!"
        } else {
            "Basic boost done. Grant Shizuku for better results."
        }
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    override fun onResume() {
        super.onResume()
        updateShizukuStatus()
    }
}
