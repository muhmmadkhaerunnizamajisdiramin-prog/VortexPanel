package com.vortexpanel.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.outlined.Memory
import androidx.compose.material.icons.outlined.Speed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.content.Context
import com.vortexpanel.ui.theme.*
import com.vortexpanel.utils.BoostUtils

@Composable
fun HomeScreen(
    context: Context,
    isShizukuRunning: Boolean,
    isPermissionGranted: Boolean,
    onRequestPermission: () -> Unit,
    onBoostClick: () -> Unit
) {
    val availableRam = remember { BoostUtils.getAvailableRam(context) }
    val totalRam = remember { BoostUtils.getTotalRam(context) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(VortexBlack)
            .verticalScroll(rememberScrollState())
            .padding(20.dp)
    ) {
        Text(
            text = "VORTEX PANEL",
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold,
            color = VortexGreen
        )
        Text(
            text = "Game Performance Booster",
            fontSize = 14.sp,
            color = VortexTextSecondary,
            modifier = Modifier.padding(bottom = 24.dp)
        )

        // Shizuku Status
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = VortexCard)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(12.dp)
                            .clip(CircleShape)
                            .background(
                                when {
                                    isShizukuRunning && isPermissionGranted -> VortexGreen
                                    isShizukuRunning -> VortexOrange
                                    else -> VortexRed
                                }
                            )
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Shizuku Status",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = VortexTextPrimary
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = when {
                        isShizukuRunning && isPermissionGranted -> "Connected & Permission Granted"
                        isShizukuRunning -> "Running - Permission Needed"
                        else -> "Not Running - Please start Shizuku"
                    },
                    fontSize = 13.sp,
                    color = VortexTextSecondary
                )

                if (isShizukuRunning && !isPermissionGranted) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = onRequestPermission,
                        colors = ButtonDefaults.buttonColors(containerColor = VortexGreen),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Grant Permission", color = VortexBlack, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // RAM Info
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            InfoCard(
                modifier = Modifier.weight(1f),
                icon = Icons.Outlined.Memory,
                value = "$availableRam MB",
                label = "Available RAM"
            )
            InfoCard(
                modifier = Modifier.weight(1f),
                icon = Icons.Outlined.Speed,
                value = "$totalRam MB",
                label = "Total RAM"
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Boost Button
        Button(
            onClick = onBoostClick,
            modifier = Modifier
                .fillMaxWidth()
                .height(64.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = VortexGreen)
        ) {
            Icon(Icons.Default.Bolt, contentDescription = null, tint = VortexBlack, modifier = Modifier.size(28.dp))
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = "ONE-TAP BOOST",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = VortexBlack
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            text = "Quick Actions",
            fontSize = 16.sp,
            fontWeight = FontWeight.SemiBold,
            color = VortexTextPrimary,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        QuickAction(Icons.Default.CleaningServices, "Clear RAM", "Free up memory")
        QuickAction(Icons.Default.Bolt, "Performance Mode", "Maximize CPU power")
        QuickAction(Icons.Default.SportsEsports, "Game Launcher", "Launch optimized games")
    }
}

@Composable
fun InfoCard(
    modifier: Modifier = Modifier,
    icon: ImageVector,
    value: String,
    label: String
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = VortexCard)
    ) {
        Column(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(icon, contentDescription = null, tint = VortexGreen, modifier = Modifier.size(28.dp))
            Spacer(modifier = Modifier.height(8.dp))
            Text(value, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = VortexTextPrimary)
            Text(label, fontSize = 12.sp, color = VortexTextSecondary)
        }
    }
}

@Composable
fun QuickAction(icon: ImageVector, title: String, subtitle: String) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = VortexCard)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(VortexGreen.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = VortexGreen, modifier = Modifier.size(24.dp))
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = VortexTextPrimary)
                Text(subtitle, fontSize = 12.sp, color = VortexTextSecondary)
            }
            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = VortexTextSecondary)
        }
    }
}
