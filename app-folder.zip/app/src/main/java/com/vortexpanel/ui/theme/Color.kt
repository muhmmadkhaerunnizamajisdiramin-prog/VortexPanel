package com.vortexpanel.ui.theme

import androidx.compose.ui.graphics.Color

val VortexBlack = Color(0xFF0A0A0A)
val VortexDarkGray = Color(0xFF121212)
val VortexCard = Color(0xFF1A1A1A)
val VortexGreen = Color(0xFF00E676)
val VortexGreenDark = Color(0xFF00C853)
val VortexTextPrimary = Color(0xFFFFFFFF)
val VortexTextSecondary = Color(0xFFB0B0B0)
val VortexRed = Color(0xFFFF5252)
val VortexOrange = Color(0xFFFFAB40)
