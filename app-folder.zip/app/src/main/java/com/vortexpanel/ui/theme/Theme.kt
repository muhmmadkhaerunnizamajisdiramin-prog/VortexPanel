package com.vortexpanel.ui.theme

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val VortexColorScheme = darkColorScheme(
    primary = VortexGreen,
    onPrimary = VortexBlack,
    primaryContainer = VortexGreenDark,
    onPrimaryContainer = VortexTextPrimary,
    secondary = VortexGreen,
    onSecondary = VortexBlack,
    background = VortexBlack,
    onBackground = VortexTextPrimary,
    surface = VortexCard,
    onSurface = VortexTextPrimary,
    surfaceVariant = VortexDarkGray,
    onSurfaceVariant = VortexTextSecondary,
    error = VortexRed,
    onError = VortexTextPrimary
)

@Composable
fun VortexPanelTheme(content: @Composable () -> Unit) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = VortexBlack.toArgb()
            window.navigationBarColor = VortexBlack.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
        }
    }

    MaterialTheme(
        colorScheme = VortexColorScheme,
        content = content
    )
}
