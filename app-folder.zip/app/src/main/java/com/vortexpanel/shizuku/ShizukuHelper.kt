package com.vortexpanel.shizuku

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

object ShizukuHelper {

    fun isShizukuAvailable(): Boolean {
        return try {
            Shizuku.pingBinder()
        } catch (e: Exception) {
            false
        }
    }

    fun isPermissionGranted(): Boolean {
        return try {
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (e: Exception) {
            false
        }
    }

    fun requestPermission(requestCode: Int = 1001) {
        try {
            if (!isPermissionGranted()) {
                Shizuku.requestPermission(requestCode)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun addBinderReceivedListener(listener: () -> Unit) {
        Shizuku.addBinderReceivedListener { listener() }
    }

    fun addBinderDeadListener(listener: () -> Unit) {
        Shizuku.addBinderDeadListener { listener() }
    }

    fun addRequestPermissionResultListener(listener: (Int, Int) -> Unit) {
        Shizuku.addRequestPermissionResultListener { requestCode, grantResult ->
            listener(requestCode, grantResult)
        }
    }
}
